# Day 2 chart contract verification

Use Helm 3 and Python 3.11+ with `tests/requirements.txt` installed in the test
environment. From the repository root:

```text
helm lint infrastructure/kubernetes/helm/haukai
helm lint infrastructure/kubernetes/helm/haukai -f infrastructure/kubernetes/helm/haukai/tests/representative.yaml
helm template review infrastructure/kubernetes/helm/haukai --namespace haukai
helm template review infrastructure/kubernetes/helm/haukai --namespace haukai -f infrastructure/kubernetes/helm/haukai/tests/representative.yaml
python infrastructure/kubernetes/helm/haukai/tests/test_chart.py
```

If Helm is outside PATH, set `HELM_BIN` to its executable. Tests parse actual
Helm output, check role/configuration and network edges, and validate strict
Kubernetes 1.27 schemas. Fixtures contain synthetic resource names and public
configuration only. No cluster, broker, DB, AWS credentials or sends are used.

`values.yaml` documents the external Secret and approved communication inputs.
Its empty Secret/CIDR/Ingress-selector defaults render for inspection but do not
provide a working deployment. Operators must supply the existing runtime inputs
and verify Redis non-persistence before acknowledging it. Capacity, probe timing
and Redis-dependent Worker restart behavior remain 待确认 for customer workloads.

Successful static checks prove rendered manifest behavior only. CNI enforcement,
managed-service networking, live IRSA, install/upgrade/rollback and production
availability require their separately scoped deployment evidence. Month 3 permits
IPv4 TCP 443; non-443 or IPv6-only Webhooks may be unreachable. Domain filtering
is a customer-driven Month 4 task. Cluster DNS egress targets the conventional
`kube-system` / `k8s-app: kube-dns` selectors; clusters that label CoreDNS
differently need operator-adjusted NetworkPolicy inputs. The full customer guide
belongs to Day 3.
