"""Static Helm contract tests. Run directly; no app, DB or cluster is needed."""

from __future__ import annotations

import ast
import os
import re
import shutil
import socket
import subprocess
import sys
import unittest
from pathlib import Path
from typing import Any
from unittest.mock import Mock, patch

import yaml
from kubernetes_validate import validate

CHART = Path(__file__).resolve().parents[1]
HELM = os.environ.get("HELM_BIN") or shutil.which("helm")
Document = dict[str, Any]


def helm(*args: str) -> str:
    if not HELM:
        raise RuntimeError("Install Helm 3 or set HELM_BIN to its executable")
    result = subprocess.run(
        [HELM, *args], capture_output=True, text=True, encoding="utf-8", check=False
    )
    if result.returncode:
        raise AssertionError(result.stderr + result.stdout)
    return result.stdout


def render(*overrides: str, representative: bool = False) -> list[Document]:
    args = ["template", "review", str(CHART), "--namespace", "haukai"]
    if representative:
        args += ["-f", str(CHART / "tests/representative.yaml")]
    for override in overrides:
        args += ["--set", override]
    return [doc for doc in yaml.safe_load_all(helm(*args)) if doc]


def resource(docs: list[Document], kind: str, suffix: str) -> Document:
    return next(
        d for d in docs if d["kind"] == kind and d["metadata"]["name"].endswith(suffix)
    )


def policies(docs: list[Document]) -> dict[str, Document]:
    return {
        d["spec"]["podSelector"]["matchLabels"]["app.kubernetes.io/component"]: d[
            "spec"
        ]
        for d in docs
        if d["kind"] == "NetworkPolicy"
    }


def ports(rules: list[Document]) -> set[tuple[str, int]]:
    return {(p["protocol"], p["port"]) for rule in rules for p in rule["ports"]}


def pod_spec(docs: list[Document], role: str) -> Document:
    return resource(docs, "Deployment", "-" + role)["spec"]["template"]["spec"]


def component_labels(role: str) -> dict[str, str]:
    return {
        "app.kubernetes.io/name": "haukai",
        "app.kubernetes.io/instance": "review",
        "app.kubernetes.io/component": role,
    }


def probe_exit_code(command: list[str], response: Document | None) -> int:
    inspect = Mock()
    inspect.ping.return_value = response
    module = Mock()
    module.celery_app.control.inspect.return_value = inspect
    with patch.dict(sys.modules, {"app.celery_app": module}):
        try:
            # Execute the checked-in chart probe against a controlled public API.
            exec(command[2], {})  # noqa: S102
        except SystemExit as outcome:
            return int(outcome.code)
    raise AssertionError("Worker probe did not exit")


class ChartTests(unittest.TestCase):
    def test_lint(self) -> None:
        helm("lint", str(CHART))
        helm("lint", str(CHART), "-f", str(CHART / "tests/representative.yaml"))

    def test_default_runtime_config(self) -> None:
        config = resource(render(), "ConfigMap", "-config")["data"]
        self.assertEqual(
            config,
            {
                "HAWKAI_ENV": "production",
                "TIKA_SERVER_URL": "http://review-haukai-tika:9998",
                "SCAN_UPLOAD_MAX_BYTES": "10485760",
                "ASYNC_SCAN_ENABLED": "true",
                "CONNECTOR_SCHEDULED_SCAN_ENABLED": "true",
                "NOTIFICATIONS_ENABLED": "true",
                "NOTIFICATION_FROM_EMAIL": "notifications@haukai.io",
                "CELERY_WORKER_MAX_MEMORY_KB": "2097152",
                "REDIS_EPHEMERAL_BROKER_CONFIRMED": "false",
            },
        )
        self.assertNotIn("HAWKAI_AWS_REGION", config)

    def test_default_environment_sources(self) -> None:
        docs = render()
        for role in ("api", "worker", "scheduler"):
            with self.subTest(role=role):
                sources = pod_spec(docs, role)["containers"][0]["envFrom"]
                self.assertEqual(
                    sources, [{"configMapRef": {"name": "review-haukai-config"}}]
                )

    def test_scheduler_singleton(self) -> None:
        docs = render("replicaCount.scheduler=7")
        scheduler = resource(docs, "Deployment", "-scheduler")["spec"]
        self.assertEqual(scheduler["replicas"], 1)
        self.assertEqual(scheduler["strategy"], {"type": "Recreate"})
        self.assertEqual(pod_spec(docs, "scheduler")["restartPolicy"], "Always")
        self.assertEqual(
            pod_spec(docs, "scheduler")["containers"][0]["resources"]["limits"][
                "memory"
            ],
            "512Mi",
        )

    def test_tika_resources(self) -> None:
        container = pod_spec(render(), "tika")["containers"][0]
        self.assertEqual(container["resources"]["requests"]["memory"], "512Mi")
        self.assertEqual(container["resources"]["limits"]["memory"], "2Gi")

    def test_irsa_absent_by_default(self) -> None:
        self.assertNotIn(
            "annotations", resource(render(), "ServiceAccount", "haukai")["metadata"]
        )

    def test_runtime_overrides(self) -> None:
        config = resource(render(representative=True), "ConfigMap", "-config")["data"]
        expected = {
            "AUTH0_ISSUER": "https://fixture.auth0.com/",
            "AUTH0_AUDIENCE": "https://fixture-api.example.com",
            "HAWKAI_ENV": "staging",
            "SCAN_UPLOAD_MAX_BYTES": "12582912",
            "CONNECTOR_SCHEDULED_SCAN_ENABLED": "false",
            "NOTIFICATIONS_ENABLED": "false",
            "NOTIFICATION_FROM_EMAIL": "fixture@example.com",
            "CELERY_WORKER_MAX_MEMORY_KB": "1048576",
            "REDIS_EPHEMERAL_BROKER_CONFIRMED": "true",
        }
        self.assertNotIn("HAWKAI_AWS_REGION", config)
        for name, value in expected.items():
            with self.subTest(key=name):
                self.assertEqual(config[name], value)

    def test_external_secret_sources(self) -> None:
        docs = render(representative=True)
        for role in ("api", "worker", "scheduler"):
            with self.subTest(role=role):
                sources = pod_spec(docs, role)["containers"][0]["envFrom"]
                self.assertEqual(sources[1], {"secretRef": {"name": "fixture-runtime"}})

    def test_irsa_configured(self) -> None:
        metadata = resource(render(representative=True), "ServiceAccount", "haukai")[
            "metadata"
        ]
        self.assertEqual(
            metadata["annotations"]["eks.amazonaws.com/role-arn"],
            "arn:aws:iam::123456789012:role/FixtureHaukai",
        )

    def test_api_rollout(self) -> None:
        api = resource(render(), "Deployment", "-api")["spec"]
        self.assertEqual(
            api["strategy"],
            {
                "type": "RollingUpdate",
                "rollingUpdate": {"maxSurge": 1},
            },
        )

    def test_preferred_role_anti_affinity(self) -> None:
        docs = render()
        for role in ("api", "worker"):
            with self.subTest(role=role):
                affinity = pod_spec(docs, role)["affinity"]["podAntiAffinity"]
                self.assertNotIn(
                    "requiredDuringSchedulingIgnoredDuringExecution", affinity
                )
                term = affinity["preferredDuringSchedulingIgnoredDuringExecution"][0][
                    "podAffinityTerm"
                ]
                self.assertEqual(term["topologyKey"], "kubernetes.io/hostname")
                self.assertEqual(
                    term["labelSelector"]["matchLabels"], component_labels(role)
                )

    def test_api_http_probes(self) -> None:
        container = pod_spec(render(), "api")["containers"][0]
        for probe in ("livenessProbe", "readinessProbe"):
            with self.subTest(probe=probe):
                self.assertEqual(
                    container[probe]["httpGet"], {"path": "/", "port": "http"}
                )

    def test_worker_runtime_controls(self) -> None:
        docs = render(representative=True)
        self.assertNotIn("replicas", resource(docs, "Deployment", "-worker")["spec"])
        container = pod_spec(docs, "worker")["containers"][0]
        self.assertIn("--concurrency=2", container["command"])
        self.assertEqual(container["resources"]["limits"]["memory"], "4Gi")

    def test_worker_liveness_accepts_idle_response(self) -> None:
        command = pod_spec(render(), "worker")["containers"][0]["livenessProbe"][
            "exec"
        ]["command"]
        ast.parse(command[2])
        response = {"celery@" + socket.gethostname(): {"ok": "pong"}}
        self.assertEqual(probe_exit_code(command, response), 0)

    def test_worker_liveness_rejects_missing_response(self) -> None:
        command = pod_spec(render(), "worker")["containers"][0]["livenessProbe"][
            "exec"
        ]["command"]
        self.assertEqual(probe_exit_code(command, None), 1)

    def test_optional_runtime_keys_omitted(self) -> None:
        docs = render("tika.enabled=false", "notifications.fromEmail=", "aws.region=")
        config = resource(docs, "ConfigMap", "-config")["data"]
        for name in (
            "TIKA_SERVER_URL",
            "NOTIFICATION_FROM_EMAIL",
            "HAWKAI_AWS_REGION",
            "AUTH0_ISSUER",
            "AUTH0_AUDIENCE",
            "AUTH0_DOMAIN",
        ):
            with self.subTest(key=name):
                self.assertNotIn(name, config)

    def test_worker_fixed_replicas_without_hpa(self) -> None:
        docs = render("autoscaling.worker.enabled=false")
        self.assertEqual(resource(docs, "Deployment", "-worker")["spec"]["replicas"], 3)

    def test_auth0_domain_normalization(self) -> None:
        for domain in ("fixture.auth0.com", "https://fixture.auth0.com/"):
            with self.subTest(domain=domain):
                config = resource(
                    render("auth0.domain=" + domain), "ConfigMap", "-config"
                )["data"]
                self.assertEqual(config["AUTH0_ISSUER"], "https://fixture.auth0.com/")

    def test_policy_component_selection(self) -> None:
        network = policies(render(representative=True))
        self.assertEqual(set(network), {"api", "worker", "scheduler", "tika"})
        for role, policy in network.items():
            with self.subTest(role=role):
                self.assertEqual(set(policy["policyTypes"]), {"Ingress", "Egress"})
                self.assertEqual(
                    policy["podSelector"]["matchLabels"], component_labels(role)
                )

    def test_api_ingress_controller_rule(self) -> None:
        rule = policies(render(representative=True))["api"]["ingress"][0]
        self.assertEqual(
            rule["from"],
            [
                {
                    "namespaceSelector": {
                        "matchLabels": {"kubernetes.io/metadata.name": "ingress-nginx"}
                    },
                    "podSelector": {
                        "matchLabels": {"app.kubernetes.io/name": "ingress-nginx"}
                    },
                }
            ],
        )
        self.assertEqual(ports([rule]), {("TCP", 8000)})

    def test_internal_ingress_and_tika_isolation(self) -> None:
        network = policies(render(representative=True))
        for role in ("worker", "scheduler"):
            self.assertEqual(network[role]["ingress"], [])
        self.assertEqual(network["tika"]["egress"], [])
        rule = network["tika"]["ingress"][0]
        self.assertEqual(ports([rule]), {("TCP", 9998)})
        self.assertEqual(
            rule["from"], [{"podSelector": {"matchLabels": component_labels("worker")}}]
        )

    def test_role_egress_ports(self) -> None:
        network = policies(render(representative=True))
        common = {("UDP", 53), ("TCP", 53), ("TCP", 6379), ("TCP", 443)}
        expected = {
            "api": common | {("TCP", 5432)},
            "worker": common | {("TCP", 5432), ("TCP", 9998)},
            "scheduler": common,
        }
        for role, allowed in expected.items():
            with self.subTest(role=role):
                self.assertEqual(ports(network[role]["egress"]), allowed)

    def test_dns_peers(self) -> None:
        network = policies(render(representative=True))
        expected = [
            {
                "namespaceSelector": {
                    "matchLabels": {"kubernetes.io/metadata.name": "kube-system"}
                },
                "podSelector": {"matchLabels": {"k8s-app": "kube-dns"}},
            }
        ]
        for role in ("api", "worker", "scheduler"):
            with self.subTest(role=role):
                rule = network[role]["egress"][0]
                self.assertEqual(rule["to"], expected)
                self.assertEqual(ports([rule]), {("UDP", 53), ("TCP", 53)})

    def test_external_cidr_port_binding(self) -> None:
        network = policies(render(representative=True))
        bindings = {"10.0.1.0/24": 5432, "10.0.2.0/24": 6379, "0.0.0.0/0": 443}
        for role in ("api", "worker", "scheduler"):
            rules = network[role]["egress"]
            external = {
                p["ipBlock"]["cidr"]: r
                for r in rules
                for p in r["to"]
                if "ipBlock" in p
            }
            expected = {"10.0.2.0/24", "0.0.0.0/0"}
            if role != "scheduler":
                expected.add("10.0.1.0/24")
            with self.subTest(role=role):
                self.assertEqual(set(external), expected)
                for cidr, rule in external.items():
                    self.assertEqual(ports([rule]), {("TCP", bindings[cidr])})

    def test_worker_tika_egress_peer(self) -> None:
        rules = policies(render(representative=True))["worker"]["egress"]
        rule = next(r for r in rules if ports([r]) == {("TCP", 9998)})
        self.assertEqual(
            rule["to"], [{"podSelector": {"matchLabels": component_labels("tika")}}]
        )

    def test_empty_dependency_cidrs(self) -> None:
        network = policies(
            render("networkPolicy.egressAllowAllHTTPS=false", "tika.enabled=false")
        )
        self.assertEqual(set(network), {"api", "worker", "scheduler"})
        for role, policy in network.items():
            with self.subTest(role=role):
                self.assertEqual(policy["ingress"], [])
                self.assertEqual(ports(policy["egress"]), {("TCP", 53), ("UDP", 53)})

    def test_network_policy_disable_switch(self) -> None:
        self.assertEqual(policies(render("networkPolicy.enabled=false")), {})

    def test_empty_ingress_selector_omits_allowance(self) -> None:
        # values.yaml defaults are empty maps {}; those must omit Ingress→API
        # rather than render empty matchLabels that match every peer.
        self.assertEqual(policies(render())["api"]["ingress"], [])
        for field in ("namespaceSelector", "podSelector"):
            # Helm --set cannot express an empty map; null is empty too.
            override = "networkPolicy.ingressController." + field + "=null"
            with self.subTest(field=field):
                self.assertEqual(
                    policies(render(override, representative=True))["api"]["ingress"],
                    [],
                )

    def test_network_ports_follow_values(self) -> None:
        network = policies(
            render(
                "database.port=5433",
                "redis.port=6380",
                "networkPolicy.egressAllowAllHTTPS=false",
                representative=True,
            )
        )
        for role in ("api", "worker", "scheduler"):
            allowed = ports(network[role]["egress"])
            self.assertIn(("TCP", 6380), allowed)
            self.assertNotIn(("TCP", 6379), allowed)
            self.assertNotIn(("TCP", 443), allowed)
            self.assertNotIn(("TCP", 8443), allowed)
            self.assertEqual(("TCP", 5433) in allowed, role != "scheduler")

    def test_environment_validation(self) -> None:
        with self.assertRaisesRegex(AssertionError, "hawkaiEnv must be"):
            render("hawkaiEnv=invalid")

    def test_resource_identity_and_namespaces(self) -> None:
        for docs in (render(), render(representative=True)):
            identities = [(doc["kind"], doc["metadata"]["name"]) for doc in docs]
            self.assertEqual(len(identities), len(set(identities)))
            for doc in docs:
                self.assertEqual(doc["metadata"]["namespace"], "haukai")

    def test_deployment_selector_matches_pods(self) -> None:
        for doc in render():
            if doc["kind"] != "Deployment":
                continue
            spec = doc["spec"]
            self.assertTrue(
                spec["selector"]["matchLabels"].items()
                <= spec["template"]["metadata"]["labels"].items()
            )
            self.assertTrue(spec["template"]["spec"]["containers"])

    def test_configmap_types_and_external_keys(self) -> None:
        for docs in (render(), render(representative=True)):
            config = resource(docs, "ConfigMap", "-config")["data"]
            self.assertTrue(all(isinstance(v, str) for v in config.values()))
            for name in (
                "DATABASE_URL",
                "REDIS_URL",
                "CORS_ALLOWED_ORIGINS",
                "AWS_SES_REGION",
                "CONNECTOR_IMMEDIATE_SCAN_MAX_OBJECTS",
                "CONNECTOR_IMMEDIATE_SCAN_DISPATCH_DEADLINE_SECONDS",
            ):
                self.assertNotIn(name, config)

    def test_secret_material_absent(self) -> None:
        for docs in (render(), render(representative=True)):
            self.assertFalse({"Secret", "ExternalSecret"} & {d["kind"] for d in docs})
            self.assertIsNone(
                re.search(
                    r"AKIA[A-Z0-9]{16}|-----BEGIN .*PRIVATE KEY-----|password=",
                    yaml.safe_dump(docs),
                )
            )
        values = yaml.safe_load((CHART / "values.yaml").read_text(encoding="utf-8"))
        self.assertEqual(values["secrets"], {"existingSecretName": ""})

    def test_kubernetes_schemas(self) -> None:
        variants = [
            render(),
            render(representative=True),
            render("networkPolicy.enabled=false", "tika.enabled=false"),
            render(
                "ingress.host=fixture.example.com",
                "ingress.tlsSecretName=fixture-tls",
                "autoscaling.worker.enabled=false",
            ),
        ]
        for docs in variants:
            for doc in docs:
                with self.subTest(kind=doc["kind"], name=doc["metadata"]["name"]):
                    validate(doc, desired_version="1.27.0", strict=True)


if __name__ == "__main__":
    unittest.main()
