{{- define "haukai.name" -}}
{{- .Chart.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "haukai.fullname" -}}
{{- /* Reserve 10 characters for the longest component suffix, -scheduler. */ -}}
{{- printf "%s-%s" .Release.Name (include "haukai.name" .) | trunc 53 | trimSuffix "-" -}}
{{- end -}}

{{- define "haukai.labels" -}}
helm.sh/chart: {{ printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | quote }}
app.kubernetes.io/name: {{ include "haukai.name" . | quote }}
app.kubernetes.io/instance: {{ .Release.Name | quote }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service | quote }}
{{- end -}}

{{- define "haukai.selectorLabels" -}}
app.kubernetes.io/name: {{ include "haukai.name" . | quote }}
app.kubernetes.io/instance: {{ .Release.Name | quote }}
{{- end -}}
